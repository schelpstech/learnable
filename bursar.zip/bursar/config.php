<?php
include "../config.php";
?>