<?php
include "../conf.php";
?>